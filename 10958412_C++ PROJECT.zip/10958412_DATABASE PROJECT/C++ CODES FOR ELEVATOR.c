#include <iostream>
#include <vector>

class Person {
private:
    const int currentFloor;
    const int destinationFloor;

public:
    Person(int currentFloor, int destinationFloor) : currentFloor(currentFloor), destinationFloor(destinationFloor) {}

    void pressButton(int floor) {
        // Allow the person to change their destination floor while inside the elevator
        const_cast<int&>(destinationFloor) = floor;
    }

    int getCurrentFloor() const {
        return currentFloor;
    }

    int getDestinationFloor() const {
        return destinationFloor;
    }
};

class Elevator {
private:
    int currentFloor;
    int destinationFloor;
    bool isOpen;
    bool isMoving;
    std::vector<Person> passengers;
    int maxCapacity;

public:
    Elevator(int maxCapacity) : currentFloor(1), destinationFloor(1), isOpen(false), isMoving(false), maxCapacity(maxCapacity) {}

    void openDoor() {
        isOpen = true;
    }

    void closeDoor() {
        isOpen = false;
    }

    void moveToFloor(int floor) {
        destinationFloor = floor;
        isMoving = true;

        const int direction = (destinationFloor > currentFloor) ? 1 : -1;

        while (currentFloor != destinationFloor) {
            currentFloor += direction;
            std::cout << "Elevator is now at floor " << currentFloor << std::endl;

            // Check if any passengers want to leave the elevator
            for (auto it = passengers.begin(); it != passengers.end(); ) {
                if (it->getDestinationFloor() == currentFloor) {
                    it = passengers.erase(it);
                    std::cout << "Passenger removed from elevator" << std::endl;
                } else {
                    ++it;
                }
            }

            // Check if any passengers want to enter the elevator
            for (int i = currentFloor; i != destinationFloor; i += direction) {
                for (auto it = passengers.begin(); it != passengers.end(); ++it) {
                    if (it->getCurrentFloor() == i && !isFull()) {
                        std::cout << "Passenger added to elevator" << std::endl;
                        break;
                    }
                }
            }
        }

        isMoving = false;
    }

    void addPassenger(Person passenger) {
        if (!isFull()) {
            passengers.push_back(passenger);
            std::cout << "Passenger added to elevator" << std::endl;
        } else {
            std::cout << "Elevator is full" << std::endl;
        }
    }

    void removePassenger(Person passenger) {
        for (auto it = passengers.begin(); it != passengers.end(); ) {
            if (*it == passenger) {
                it = passengers.erase(it);
                std::cout << "Passenger removed from elevator" << std::endl;
            } else {
                ++it;
            }
        }
    }

    bool isFull() {
return passengers.size() >= maxCapacity;
}
bool isEmpty() {
    return passengers.empty();
}
};

int main() {
Elevator elevator(10);
Person p1(1, 5);
Person p2(1, 10);
Person p3(2, 7);
Person p4(4, 6);

elevator.addPassenger(p1);
elevator.addPassenger(p2);
elevator.addPassenger(p3);
elevator.addPassenger(p4);

elevator.moveToFloor(5);

elevator.removePassenger(p1);

elevator.moveToFloor(10);

return 0;
}
